class favorites {
    constructor (tite,href,ingredients,thumbnail) {
        this.title = title;
        this.href = href;
        this.ingredients = ingredients;
        this.thumbnail = thumbnail;
    }
}

class FavoriteManager {
    constructor () {
        this.favorites = []
    }

}