class IngredientsManager {
    constructor () {
        this.ingredients = [];
        this.reducedIngredients = [];
    }
}