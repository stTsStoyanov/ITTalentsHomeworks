class CookedRecipe {
    constructor (name) {
        this.name = name;
        this.cookCount = 1;
    }
}

class CookManager {
    constructor () {
        this.cooked = [];
    }

    
}
