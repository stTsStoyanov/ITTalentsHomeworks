class ViewController{
    constructor(){
        // window.addEventListener('hashchange', this.handleHashChange);
        // window.addEventListener('load', this.handleHashChange);

        window.addEventListener('hashchange', this.handleHashChange);
        window.addEventListener('load', this.handleHashChange);

        //managers!
        this.recipieManager = new RecipeManager();
    }



    handleHashChange = () => {
        let hashIds = ["allRecipies", "favoritRecipies", "createRecipies", "myProfile"];

        let hash = window.location.hash.slice(1) || "allRecipies";


        hashIds.forEach(element => {
            let currentHash = document.getElementById(element);

            if(hash === element){
                currentHash.style.display = 'block';
            }else{
                currentHash.style.display = 'none';
            }
        });

        console.log(this.recipieManager.recipeList)

        switch(hash){
            case "allRecipies":
                this.renderRecipe();
                // break;
            case "favoritRecipies":
            case "createRecipies":
            case "myProfile":
        }
    }


    renderRecipe = (recipeList, container) =>{
        recipeList.forEach(el => console.log(el))

        // container.innerHTML = "";

        // this.recipieManager.recipeList.forEach(recipe => {

        //     let card = document.createElement('div');
        //     card.classList.add = 'card';
        //     card.style.width = 200;

        //     let img = document.createElement('img')
        //     img.src = recipe.thumbnail;
        //     img.width = 200;

        //     let name = document.createElement('div');
        //     name.innerText = recipe.title;
        //     name.classList.add = ('name');

        //     let recipeCount = document.createElement('div');
        //     recipeCount.innerText = recipe.ingredients + " ";
        //     recipeCount.classList.add = ('ingredients');

        //     let hrefData = document.createElement("div");
        //     hrefData.innerText = recipe.href;
        //     hrefData.classList.add = ('hrefData');

        //     let buttonFav = document.createElement('button');
        //     buttonFav.innerText = 'Добави в любими';
        //     buttonFav.classList.add = 'addToFav'

        //     let buttonCook = document.createElement('button');
        //     buttonCook.innerText = 'Сготви';
        //     buttonCook.classList.add = 'cookIt'


        //     card.append(
        //         img,
        //         name,
        //         recipeCount,
        //         hrefData,
        //         buttonFav,
        //         buttonCook
        //     );

        //     console.log(card);

        //     container.appendChild(card);
        // });


    }

    renderAllRecipies = () =>{
        let cardContainer = document.querySelector('#allRecipies .container');
        let input = document.getElementById('searchInput');

        input.addEventListener('input', (event) =>{
            let result = this.recipieManager.search(event.target.value);
            this.renderRecipe(result, cardContainer);
        });

        this.renderRecipe(this.recipieManager.recipeList, cardContainer);
    }


}

let viewController = new ViewController();