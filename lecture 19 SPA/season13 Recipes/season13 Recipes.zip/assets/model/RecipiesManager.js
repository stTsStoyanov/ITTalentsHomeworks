class Recipe{
    constructor(title, href, ingredients, thumbnail) {
        this.title = title;
        this.href = href;
        this.ingredients = ingredients;
        this.thumbnail = thumbnail;
    }
}

class RecipeManager{
    constructor(){
        this.recipeList = DATA.map(recipie => new Recipe(
            recipie.title,
            recipie.href,
            recipie.ingredients,
            recipie.thumbnail
        ));
    }

    search(keyword){
        return this.recipeList.filter(element => {
            return element.title.toLowerCase().includec(keyword.trim().toLowerCase());
        })
    }
}