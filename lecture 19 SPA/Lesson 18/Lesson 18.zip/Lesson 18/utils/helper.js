function createElement(kind) {
    return document.createElement(kind);
}