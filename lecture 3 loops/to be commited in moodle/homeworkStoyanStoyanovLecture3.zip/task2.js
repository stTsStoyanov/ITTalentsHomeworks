for(let counter=-20; counter<=50; counter++){
    console.log(counter)
}