let numberOne=12;
let numberTwo=15;
while(numberOne<=numberTwo){
    console.log(numberOne);
    numberOne++
}