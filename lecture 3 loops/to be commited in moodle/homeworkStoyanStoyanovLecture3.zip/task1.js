for(let counter=1; counter<=100; counter++){
    console.log(counter)
}