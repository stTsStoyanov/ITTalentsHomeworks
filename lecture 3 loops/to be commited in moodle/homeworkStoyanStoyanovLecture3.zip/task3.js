for(let counter=-10; counter<=10; counter++){
    if(counter%2 !=0){
        console.log(counter)
    }
}