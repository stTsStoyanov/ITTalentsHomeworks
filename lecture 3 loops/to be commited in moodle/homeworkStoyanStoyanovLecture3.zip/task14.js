let numberN=55;
for(let number=200; number>=10; number--){
    if(number%7 ==0 && number<numberN){
        console.log(number)
        if(number==14){console.log(7)}
    }
}