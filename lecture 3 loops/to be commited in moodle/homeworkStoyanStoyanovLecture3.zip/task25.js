let number=5;
let counter=1;
let result=1;

do{
    result*=counter;
    counter++;
}while(counter<=number);
console.log(result);