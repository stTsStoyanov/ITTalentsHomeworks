let n=5;
let counter=1;
let sum=0;
do{
    sum+=counter;
    counter++;
}while(counter<=n);
console.log(sum)