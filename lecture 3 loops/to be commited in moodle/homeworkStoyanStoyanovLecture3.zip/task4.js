for(let counter=10; counter>0; counter--){
    console.log(counter)
}