let arr=[2,5,8,5,5,5];
let possition=2;
let toBeInserted=1;
arr.splice(possition,1,toBeInserted);
console.log(arr);