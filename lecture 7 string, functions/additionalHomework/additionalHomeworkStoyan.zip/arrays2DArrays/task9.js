let arr=[5,2,8,9,6,3,0,1];
arr.sort().reverse();
console.log(`${arr}`);