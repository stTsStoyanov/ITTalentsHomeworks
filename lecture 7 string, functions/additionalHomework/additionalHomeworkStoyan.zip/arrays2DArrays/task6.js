let arr=[2,5,8];
let copyArr=[];

for(let i=0; i<arr.length; i++){
    copyArr[i]=arr[i];
}
console.log(copyArr);