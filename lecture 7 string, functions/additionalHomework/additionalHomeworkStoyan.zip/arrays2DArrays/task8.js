let arr=[5,2,8,9,6,3,0,1];
arr.sort();
console.log(`The maximum value is ${arr[arr.length-1]} and tha miminum value is ${arr[0]}`);