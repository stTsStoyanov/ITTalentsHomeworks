let arr=[2,5,8];
let sum=0;
for(let i=0; i<arr.length; i++){
    sum+=arr[i];
}
console.log(sum/arr.length);