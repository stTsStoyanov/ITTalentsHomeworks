let arr=[1,66,1024,4,5,22,701,404,"Op tozi element e unikalen", 55,6 ];
for(let i=0; i<arr.length; i++){
    if(typeof arr[i] != "number"){
        console.log(arr[i]);
    }
}