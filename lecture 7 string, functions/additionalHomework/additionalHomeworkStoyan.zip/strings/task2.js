let strOne="ala";
let strTwo="bala";
let result=strOne+strTwo;
console.log(result);