let str="";
let lengthOfString=0;
let counter=0;
while(str[counter]!=undefined){
    lengthOfString++;
    counter++
}
console.log(lengthOfString);