const DATA = [
    {
        "name": "Боян Бързаков",
        "image": "./images/1.jpeg",
        "type": "костенурка",
        "bread": "сухоземна",
        "age": 2,
        "sex": "male",
        "neededAmount": 5000,
        "currentlyRisedAmount": 2300
    },
    {
        "name": "Киро от Горубляне",
        "image": "./images/2.jpeg",
        "type": "котка",
        "bread": "улична превъзходна",
        "age": 12,
        "sex": "male",
        "neededAmount": 2600,
        "currentlyRisedAmount": 1900
    },
    {
        "name": "Асен",
        "image": "./images/3.jpg",
        "type": "видра",
        "bread": "видрите нямат породи",
        "age": 7,
        "sex": "male",
        "neededAmount": 8900,
        "currentlyRisedAmount": 4200
    },
    {
        "name": "Линда",
        "image": "./images/4.png",
        "type": "котка",
        "bread": "безполезница",
        "age": 8,
        "sex": "female",
        "neededAmount": 12000,
        "currentlyRisedAmount": 3600
    },
    {
        "name": "Томислав",
        "image": "./images/5.png",
        "type": "котка",
        "bread": "норвежец",
        "age": 2,
        "sex": "male",
        "neededAmount": 2500,
        "currentlyRisedAmount": 2500
    },
    {
        "name": "Иван",
        "image": "./images/6.png",
        "type": "куче",
        "bread": "мелез",
        "age": 2,
        "sex": "male",
        "neededAmount": 1200,
        "currentlyRisedAmount": 1200
    },
    {
        "name": "Шаро",
        "image": "./images/8.png",
        "type": "куче",
        "bread": "ретривър",
        "age": 4,
        "sex": "male",
        "neededAmount": 12400,
        "currentlyRisedAmount": 9200
    },
    {
        "name": "Спаска",
        "image": "./images/9.png",
        "type": "ламя",
        "bread": "домашна",
        "age": 420,
        "sex": "female",
        "neededAmount": 15000,
        "currentlyRisedAmount": 3500
    },
    {
        "name": "Григор",
        "image": "./images/10.png",
        "type": "вълк",
        "bread": "средногорски",
        "age": 12,
        "sex": "male",
        "neededAmount": 9000,
        "currentlyRisedAmount": 7200
    },
    {
        "name": "Гинка",
        "image": "./images/11.png",
        "type": "видра",
        "bread": "модерна",
        "age": 12,
        "sex": "female",
        "neededAmount": 19000,
        "currentlyRisedAmount": 9200
    },
    {
        "name": "Галена",
        "image": "./images/12.webp",
        "type": "змия",
        "bread": "усойница",
        "age": 3.5,
        "sex": "female",
        "neededAmount": 12000,
        "currentlyRisedAmount": 6500
    }
    
]