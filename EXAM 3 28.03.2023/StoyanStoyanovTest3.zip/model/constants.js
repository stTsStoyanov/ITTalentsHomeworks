const PAGE_IDS = ['login', 'register', 'logout', 'filters', 'details', 'cocktails','favCocktails', '404'];
const SERVER_URL = 'http://192.168.7.50:8080';
const COCKTAILS_URL = '';
