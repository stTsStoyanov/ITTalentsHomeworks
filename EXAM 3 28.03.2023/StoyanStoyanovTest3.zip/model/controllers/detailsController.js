class DetailsController{
    constructor(cocktailsManager){
        this.cocktailsManager = cocktailsManager;
    }

    render = (id) => {

        let container = getEl('details');
        container.style.border = '2px solid gray'
        container.style.margin = '25px';
        container.innerHTML = '';

        this.cocktailsManager.detailsById(id)
        .then(data => {

            let div = createEl('div');
            div.style.display = 'flex';
            div.style.width = '800px';

            let pictureContainer = createEl('div');
            pictureContainer.style.display = 'flex';
            pictureContainer.style.flexDirection = 'column';
            pictureContainer.style.justifyContent = 'center';
            pictureContainer.style.padding = '20px';
            pictureContainer.style.width = '400px';
            pictureContainer.style.background = 'green'
            let img = createEl('img');
            img.src = data.drinks[0].strDrinkThumb;
            img.width = '350';
            img.hight = '350';
            let alcoholic = createEl('h3');
            alcoholic.innerText = data.drinks[0].strAlcoholic;
            pictureContainer.style.borderRight = '2px solid gray';
            pictureContainer.append(img, alcoholic);

            let textContainer = createEl('div');
            textContainer.style.display = 'flex';
            textContainer.style.flexDirection = 'column';
            textContainer.style.width = '400px';
            textContainer.style.padding = '20px'
            // textContainer.style.background = 'pink'

            let h1 = createEl('h1');
            let tag = createEl('h3');
            tag.innerText = data.drinks[0].strTags ? data.drinks[0].strTags : 'there are no tags';
            let h2 = createEl('h3');
            let h3 = createEl('h3');
            let h4 = createEl('h3');
            h1.innerText = data.drinks[0].strDrinkAlternate ? data.drinks[0].strDrink  + ", " + data.drinks[0].strDrinkAlternate : data.drinks[0].strDrink;
            h2.innerText = data.drinks[0].strGlass;
            h3.innerText = data.drinks[0].strInstructions;
            // h4.innerText = data.slogan; 
            textContainer.append(h1,tag,h2,h3);

            let allKeys = Object.keys(data.drinks[0]); // iterating over the obj keys
            // console.log(allKeys)
            for(let i=0; i<allKeys.length; i++){
                if(allKeys[i].includes('strIngredient')){
                    // console.log(allKeys[i])
                    if(data.drinks[0][allKeys[i]] != null){
                        let p = `<p class="card-text">${data.drinks[0][allKeys[i]]}</p>`;
                        textContainer.innerHTML+=(p);
                    }
                }
            }

            let buttons = createEl('div');
            buttons.style.display = 'flex';
            buttons.style.justifyContent = 'center';
            buttons.style.margin = '15px';

            let add = createEl('input');
            add.type = 'submit';
            add.value = 'Add to fav';
            add.style.width = '100px';


            add.onclick = (event) =>{
                location.hash = 'favCocktails';

                    let favBtn = getEl('favBtn');
                    let name1 = 'Add to fav';
                    let name2 = 'Remove from fav';
                    if(event.target.value == 'Add to fav'){
                        this.cocktailsManager.addToFav(data.drinks[0].idDrink)
                        .then(el =>{
                            event.target.value = name2;
                        })
                    }else{
                        this.cocktailsManager.removeFromFav(data.drinks[0].idDrink)
                        .then(el =>{
                            event.target.value = name1;
                        })
                    }
                    console.log(event.target.value);

            }


            buttons.append(add);

            textContainer.append(buttons);


            div.append(pictureContainer, textContainer);
            container.append(div);
        })

    }
}