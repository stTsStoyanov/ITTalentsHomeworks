class AddToFav{
    constructor(){

    }
    
}