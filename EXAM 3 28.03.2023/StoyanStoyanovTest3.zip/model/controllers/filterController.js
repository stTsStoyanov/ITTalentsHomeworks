class FilterContoller{
    constructor(){

    }

    render = (data) =>{
        
    }
}