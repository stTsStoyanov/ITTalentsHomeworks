class CocktailsController {
    constructor(cocktailsManager, userManager, detailsController) {
        this.cocktailsManager = cocktailsManager;
        this.userManager = userManager;
        this.detailsController = detailsController;
    }

    displaySettings() {
        let logoutBtn = getEl('logoutBtn');
        let loginLink = getEl('loginLink');
        let logoutLink = getEl('logoutLink');
        let registerLink = getEl('registerLink');

        logoutLink.style.display = 'block';
        logoutLink.classList.add('nav-link');

        loginLink.style.display = 'none';
        loginLink.classList.remove()
        registerLink.style.display = 'none';
        registerLink.classList.remove();

        if (this.userManager.loggedUser) {
            let navUsername = getEl('navUsername');
            navUsername.innerText = this.userManager.loggedUser.username;
        }

        // this.userManager.loggedUser = JSON.parse(localStorage.getItem('loggedTEST'));
    }

    drinkOfTheDay = () => {
        this.cocktailsManager.cocktailOfTheDay()
            .then(data => {
                let ofTheDay = getEl('ofTheDay');
                ofTheDay.style.border = '1px solid gray'
                ofTheDay.style.padding = '10px';
                ofTheDay.innerHTML = '';

                let card = createEl('div');
                card.classList.add('card')
                card.style.width = '250px'
                card.innerHTML =

                    `   <h5 class="card-title">COCKTAIL OF THE DAY</h5>
                    <img src="${data.drinks[0].strDrinkThumb}" class="card-img-top" alt="...">
                    <div class="card-body">
                    <h5 class="card-title">${data.drinks[0].strDrink}</h5>
                </div>  `;

                if (data.drinks[0].strDrinkAlternate) { // if other name 
                    let h = `<h5 class="card-title">${data.drinks[0].strDrinkAlternate}</h5>`
                    card.append(h);
                }

                let allKeys = Object.keys(data.drinks[0]); // iterating over the obj keys
                // console.log(allKeys)
                for (let i = 0; i < allKeys.length; i++) {
                    if (allKeys[i].includes('strIngredient')) {
                        // console.log(allKeys[i])
                        if (data.drinks[0][allKeys[i]] != null) {
                            let p = `<p class="card-text">${data.drinks[0][allKeys[i]]}</p>`;
                            card.innerHTML += p;
                        }
                    }
                }

                let buttons = createEl('div');
                buttons.style.display = 'flex';
                buttons.style.justifyContent = 'center';


                let details = createEl('input');
                details.type = 'submit';
                details.value = 'Details';
                details.style.width = '100px';


                details.onclick = (event) => {
                    location.hash = 'details';
                    this.detailsController.render(data.drinks[0].idDrink);
                }

                buttons.append(details)
                card.append(buttons)

                ofTheDay.append(card);

            })
    }



    renderDrinks = () => {

        let searchCocktailsInput = getEl('searchCocktailsInput');

        searchCocktailsInput.oninput = debounce((event) => {
            event.preventDefault();

            let keyword = event.target.value;

            this.cocktailsManager.searchByName(keyword)
                .then(cocktail => {
                    this.allDrinks(cocktail)
                })

        }, 500)


        this.cocktailsManager.cocktailsByChar()
            .then(data => {
                this.allDrinks(data)
            })
    }

    favorits = (id, card) =>{
        let favCocktails = getEl('favCocktails');
        // favCocktails.innerHTML = '';

        this.cocktailsManager.listFav(id)
        .then(data =>{
            console.log(data)
            data.favorites.forEach(element => {
                console.log(element)
            });
        })
    }


    allDrinks = (data) => {



        console.log(data)
        let otherCocktails = getEl('otherCocktails');
        otherCocktails.innerHTML = '';

        let favCocktails = getEl('favCocktails');
        favCocktails.style.display = 'flex';
        // favCocktails.innerHTML = '';

        this.cocktailsManager.listFav()
            .then(favDrinksServer => {

                
                // console.log('opaaaaaaa')
                // console.log(favDrinksServer.favorites)
                // console.log(data.drinks)

                for (let i = 0; i < data.drinks.length; i++) {


                    let card = createEl('div');
                    card.classList.add('card')
                    card.style.width = '250px'
                    card.innerHTML =

                        ` <div> 
                            <img src="${data.drinks[i].strDrinkThumb}" class="card-img-top" alt="...">
                            <div class="card-body">
                            <h5 class="card-title">${data.drinks[i].strDrink}</h5>
                        </div>  `;


                    let buttons = createEl('div');
                    buttons.style.display = 'flex';
                    buttons.style.justifyContent = 'space-between';


                    let favBtn = createEl('input');
                    favBtn.setAttribute("id", "favBtn")
                    favBtn.type = 'submit';
                    favBtn.value = 'Add to fav';
                    favBtn.style.width = '100px'



                    let details = createEl('input');
                    details.type = 'submit';
                    details.value = 'Details';
                    details.style.width = '100px';

                    

                    details.onclick = (event) => {
                        location.hash = 'details';
                        this.detailsController.render(data.drinks[i].idDrink);
                    }

                    
                    

                    if (data.drinks[i].strDrinkAlternate) { // if other name 
                        let h = `<h5 class="card-title">${data.drinks[i].strDrinkAlternate}</h5>`
                        card.append(h);
                    }

                    let allKeys = Object.keys(data.drinks[i]); // iterating over the obj keys
                    // console.log(allKeys)
                    for (let j = 0; j < allKeys.length; j++) {
                        if (allKeys[j].includes('strIngredient')) {
                            // console.log(allKeys[j])
                            if (data.drinks[0][allKeys[j]] != null) {
                                let p = `<p class="card-text">${data.drinks[0][allKeys[j]]}</p>`;
                                card.innerHTML += p;
                            }
                        }
                    }




                    // if (favDrinksServer.favorites.includes(data.drinks[i].idDrink)) {
                    //     favCocktails.append(card);
                    // } else {
                    //     otherCocktails.append(card);
                    // }

                    favBtn.onclick = (event) =>{
                        let name1 = 'Add to fav';
                        let name2 = 'Remove from fav';
                        if(event.target.value == 'Add to fav'){
                            this.cocktailsManager.addToFav(data.drinks[i].idDrink)
                            .then(el =>{
                                event.target.value = name2;
                                favCocktails.append(card);
                                this.favorits()
                            })
                        }else{
                            this.cocktailsManager.removeFromFav(data.drinks[i].idDrink)
                            .then(el =>{
                                event.target.value = name1;
                                otherCocktails.append(card);
                            })
                        }
                        console.log(event.target.value);
                    }

                    


                    let flag = false;
                    favDrinksServer.favorites.forEach(favData =>{
                        // console.log(favData)
                        // console.log('sledvashtoto e ot data');
                        console.log(data.drinks[i].idDrink)
                        if(favData == data.drinks[i].idDrink){
                            flag = true;
                            favBtn.value = 'Remove from fav'
                        }
                    })

                    buttons.append(favBtn,details)
                    card.append(buttons)
                    

                    if(flag){
                        favCocktails.append(card);
                    }else{
                        otherCocktails.append(card);
                    }


                }




            })



    }


}