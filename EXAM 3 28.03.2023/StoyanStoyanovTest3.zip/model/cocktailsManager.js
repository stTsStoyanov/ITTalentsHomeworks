class CocktailsManager{
    constructor() {
        
    }

    listFav = () =>{
        const sessionId = JSON.parse(localStorage.getItem('loggedTEST')).sessionId;
        return makeAPICall(SERVER_URL + '/favorite-cocktails',{
            method: "GET",
            headers: {
                'identity' : sessionId
            }
        })

    }

    addToFav = (coctailId) =>{
        const sessionId = JSON.parse(localStorage.getItem('loggedTEST')).sessionId;
        return makeAPICall(SERVER_URL + '/favorite-cocktails',{
            method: "POST",
            headers: {
                'identity' : sessionId,
                'Content-Type' : 'application/json'           
            },
            body: JSON.stringify({
                'id' : coctailId 
            })
        })
    }

    removeFromFav = (coctailId) =>{
        const sessionId = JSON.parse(localStorage.getItem('loggedTEST')).sessionId;
        return makeAPICall(SERVER_URL + `/favorite-cocktails`,{
            method: "DELETE",
            headers: {
                'identity' : sessionId,
                'cocktailId' : coctailId
            }
        })
    }


    cocktailOfTheDay = () =>{
        return makeAPICall('https://thecocktaildb.com/api/json/v1/1/random.php',{
            method: "GET"
        })
    }

    cocktailsByChar = () =>{
        return makeAPICall('https://thecocktaildb.com/api/json/v1/1/search.php?f=s',{
            method: "GET"
        })
    }
    
    searchByName = (keyword) =>{
        return makeAPICall(`https://thecocktaildb.com/api/json/v1/1/search.php?s=${keyword}`,{
            method: "GET"
        })
    }

    
    detailsById = (id) =>{
        return makeAPICall(`https://thecocktaildb.com/api/json/v1/1/lookup.php?i=${id}`,{
            method: "GET"
        })
    }

    // results = () =>{
    //     const sessionId = JSON.parse(localStorage.getItem('loggedTEST')).sessionId;
    //     return makeAPICall(SERVER_URL + '/results',{
    //         method: "GET",
    //         headers: {
    //             'identity' : sessionId
    //         }
    //     })
    // }

    // vote = (partyId) =>{
    //     const sessionId = JSON.parse(localStorage.getItem('loggedTEST')).sessionId;
    //     return makeAPICall(SERVER_URL + `/vote/${partyId}`,{
    //         method: "POST",
    //         headers: {
    //             'identity' : sessionId,
    //             'Content-Type' : 'application/json'
    //         },
            
    //     })
    // }
}