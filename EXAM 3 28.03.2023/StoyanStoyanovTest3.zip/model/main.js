class ViewController {
    constructor(){
        window.addEventListener('hashchange', this.handleHashChange);
        window.addEventListener('load', this.handleHashChange);

        this.userManager = new UserManager();

        this.loginController = new LoginController(this.userManager);
        this.registerController = new RegisterController(this.userManager);
        this.logoutController = new LogoutController(this.userManager);

        this.cocktailsManager = new CocktailsManager();
        this.detailsController = new DetailsController(this.cocktailsManager)
        this.cocktailsController = new CocktailsController(this.cocktailsManager, this.userManager, this.detailsController);


    }

    handleHashChange = ()=>{
        const hash = location.hash.slice(1) || PAGE_IDS[0];

        if(!PAGE_IDS.includes(hash)){
            location.hash = '404'
            return;
        }

        let headerId = getEl('headerId');
        if(!this.userManager.loggedUser){
            headerId.style.display = 'none'
        }else{
            headerId.style.display = 'block';
        }

        if(hash === 'cocktails' && !this.userManager.loggedUser
         || hash === 'details' && !this.userManager.loggedUser 
         || hash === 'filters' && !this.userManager.loggedUser){

            if(this.userManager.loggedUser){
                let navUsername = getEl('navUsername');
                navUsername.innerText = this.userManager.loggedUser.username;
            }
            
            location.hash = 'login';
        }else if(hash === 'login' && this.userManager.loggedUser){
            location.hash = 'cocktails';
        }




        PAGE_IDS.forEach(pageId =>{
            let elements = getEl(pageId);
            hash == pageId ? elements.style.display = 'block' :
                                elements.style.display = 'none';
            

        });


        switch(hash){
            case 'login':
                this.loginController.render();
                break;
            case 'register':
                this.registerController.render();
                break;
            case 'logout':
                this.logoutController.render();
                break;
            case 'cocktails':
                this.cocktailsController.displaySettings();
                this.cocktailsController.drinkOfTheDay();
                this.cocktailsController.renderDrinks();
                break;


        }
    }
    
}

let viewController = new ViewController();